import React from 'react';
import {
  Box,
  Container,
  Heading,
  Text,
  Stack,
  FormControl,
  FormLabel,
  Input,
  Button,
  Alert,
  AlertIcon
} from '@chakra-ui/react';
import { supabase } from '../supabaseClient';
import { useNavigate, Link as RouterLink } from 'react-router-dom';

/**
 * LoginPage provides a simple form for users to sign into their account
 * using Supabase authentication.  Upon successful login the user is
 * redirected back to the apps page.  Errors returned by Supabase are
 * displayed to the user.
 */
const LoginPage = () => {
  const navigate = useNavigate();
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        setError(error.message);
      } else {
        navigate('/apps');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box as="main" py={12} px={{ base: 4, sm: 6, lg: 8 }} minH="70vh" display="flex" alignItems="center" justifyContent="center">
      <Container maxW="sm" w="full">
        <Stack spacing={6}>
          <Heading textAlign="center" fontSize="2xl" fontWeight="bold">
            Welcome back
          </Heading>
          <Text textAlign="center" color="gray.600">
            Sign in to continue your learning journey
          </Text>
          {error && (
            <Alert status="error">
              <AlertIcon />
              {error}
            </Alert>
          )}
          <Box as="form" onSubmit={handleLogin} bg="white" p={6} borderWidth="1px" borderColor="gray.200" rounded="lg" shadow="sm">
            <Stack spacing={4}>
              <FormControl isRequired>
                <FormLabel>Email address</FormLabel>
                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
              </FormControl>
              <FormControl isRequired>
                <FormLabel>Password</FormLabel>
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="********" />
              </FormControl>
              <Button type="submit" colorScheme="brand" isLoading={loading} loadingText="Signing in..." w="full">
                Sign In
              </Button>
            </Stack>
          </Box>
          <Text textAlign="center" fontSize="sm" color="gray.600">
            Don't have an account?{' '}
            <Button variant="link" as={RouterLink} to="/auth/register" colorScheme="brand" size="sm">
              Sign up
            </Button>
          </Text>
        </Stack>
      </Container>
    </Box>
  );
};

export default LoginPage;