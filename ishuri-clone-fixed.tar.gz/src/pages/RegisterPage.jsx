import React from 'react';
import {
  Box,
  Container,
  Heading,
  Text,
  Stack,
  FormControl,
  FormLabel,
  Input,
  Button,
  Alert,
  AlertIcon
} from '@chakra-ui/react';
import { supabase } from '../supabaseClient';
import { useNavigate, Link as RouterLink } from 'react-router-dom';

/**
 * RegisterPage allows new users to create an account via Supabase.  A
 * successful registration will also log the user in automatically and
 * redirect them to the apps page.  If email confirmation is enabled in
 * your Supabase project you may wish to provide additional messaging.
 */
const RegisterPage = () => {
  const navigate = useNavigate();
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState('');

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const { error } = await supabase.auth.signUp({ email, password });
      if (error) {
        setError(error.message);
      } else {
        // After sign up Supabase will automatically create a session if email
        // confirmation is not required.  Redirect to apps page.
        navigate('/apps');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box as="main" py={12} px={{ base: 4, sm: 6, lg: 8 }} minH="70vh" display="flex" alignItems="center" justifyContent="center">
      <Container maxW="sm" w="full">
        <Stack spacing={6}>
          <Heading textAlign="center" fontSize="2xl" fontWeight="bold">
            Create an account
          </Heading>
          <Text textAlign="center" color="gray.600">
            Join Ishuri Platform to unlock personalised learning tools
          </Text>
          {error && (
            <Alert status="error">
              <AlertIcon />
              {error}
            </Alert>
          )}
          <Box as="form" onSubmit={handleRegister} bg="white" p={6} borderWidth="1px" borderColor="gray.200" rounded="lg" shadow="sm">
            <Stack spacing={4}>
              <FormControl isRequired>
                <FormLabel>Email address</FormLabel>
                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
              </FormControl>
              <FormControl isRequired>
                <FormLabel>Password</FormLabel>
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="********" />
              </FormControl>
              <Button type="submit" colorScheme="brand" isLoading={loading} loadingText="Signing up..." w="full">
                Sign Up
              </Button>
            </Stack>
          </Box>
          <Text textAlign="center" fontSize="sm" color="gray.600">
            Already have an account?{' '}
            <Button variant="link" as={RouterLink} to="/auth/login" colorScheme="brand" size="sm">
              Log in
            </Button>
          </Text>
        </Stack>
      </Container>
    </Box>
  );
};

export default RegisterPage;