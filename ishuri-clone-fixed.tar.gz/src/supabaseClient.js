import { createClient } from '@supabase/supabase-js';

// Initialise the Supabase client using environment variables exposed via
// Vite.  Users of this project must supply their own Supabase URL and
// public anon key in a `.env.local` file (see `.env.example`).  See
// https://supabase.com/docs/guides/getting-started for details on how to
// obtain these values.
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);